Juan Aguirre 9/25/2018
Operating Systems Assignment 1 
Run make file by using "make" command in linux, and then run "./ctp" for child to parent process
that runs pre.c and sort.c. Input data and when done inputing data "ctrl-d" to start the sorting
and grouping or enter 10 items.(Note: I was unsure how to take off warnings but it works)
For the third task, run "./uni ls -la" or any other linux  command after ./uni
